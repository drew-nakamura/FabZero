# Verified kernel handoff

Board reported: AMD SK-KV260-G. Windows 11, Vivado/Vitis 2025.2.
Run: 6bccf63e-f83a-4e12-88e6-78b20d120b65; evidence: rtl_simulation.
N=8, LANES=1; clock period 10 ns is a target, not achieved timing.

From this archive root, replay the exact RTL with Icarus:

    iverilog -g2012 -s tb -Ptb.N=8 -Ptb.LANES=1 -o replay hardware/matmul.sv hardware/tb.sv
    vvp replay

Compare printed OUT values to expected.json. This replay is not a board run.
Generated RTL archives include the original independent cycle monitor in this replay.

In the Vivado Tcl shell, inspect `version -short`, `get_board_parts *kv260*`,
and `get_parts *xck26*`. Select the exact installed part matching the board.
From a Windows command prompt with Vivado on PATH:

    vivado -mode batch -source integration/synth.tcl -tclargs EXACT_INSTALLED_PART 8 1 10 build/ooc

That produces out-of-context synthesis only, not a deployable bitstream.
The integration/ files are current aids, separately hashed in manifest.json;
the wrapper has not been verified against this exact archived kernel on a board.
See integration/BRINGUP.md. Confirm PS block design, reset/clock, MMIO address,
OS/firmware and compatible loader before deployment. No physical address is assumed.
For an ASIC-origin run this is a proposed FPGA retarget, not FPGA validation.
